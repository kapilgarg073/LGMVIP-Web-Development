---
title: Hello World
date: "2021-08-23"
---

India, officially the Republic of India (Hindi: Bhārat Gaṇarājya),[23] is a country in South Asia. It is the second-most populous country, the seventh-largest country by land area, and the most populous democracy in the world. Bounded by the Indian Ocean on the south, the Arabian Sea on the southwest, and the Bay of Bengal on the southeast, it shares land borders with Pakistan to the west;

China, Nepal, and Bhutan to the north; and Bangladesh and Myanmar to the east. In the Indian Ocean, India is in the vicinity of Sri Lanka and the Maldives; its Andaman and Nicobar Islands share a maritime border with Thailand, Myanmar and Indonesia.

<!-- end -->

The Indian early medieval age, from 600 to 1200 CE, is defined by regional kingdoms and cultural diversity. When Harsha of Kannauj, who ruled much of the Indo-Gangetic Plain from 606 to 647 CE, attempted to expand southwards, he was defeated by the Chalukya ruler of the Deccan.
When his successor attempted to expand eastwards, he was defeated by the Pala king of Bengal. When the Chalukyas attempted to expand southwards, they were defeated by the Pallavas from farther south, who in turn were opposed by the Pandyas and the Cholas from still farther south.
 No ruler of this period was able to create an empire and consistently control lands much beyond their core region. During this time, pastoral peoples, whose land had been cleared to make way for the growing agricultural economy, were accommodated within caste society, as were new non-traditional ruling classes. The caste system consequently began to show regional differences



There are 1.21 billion people living in India. India is the second largest country by the number of people living in it, with China being the first. Experts think that by the year 2030, India will be the first.
 About 65% of Indians live in rural areas, or land set aside for farming. The largest cities in India are Mumbai, Kolkata, Delhi, Chennai, Bangalore, Hyderabad, and Ahmedabad. India has 23 official languages. Altogether, 1,625 languages are spoken in India