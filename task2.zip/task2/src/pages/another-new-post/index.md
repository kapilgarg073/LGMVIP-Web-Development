---
title: My Second Post!
date: "2021-08-24"
---

The track on a railway or railroad, also known as the permanent way, is the structure consisting of the rails, fasteners, railroad ties (sleepers, British English) and ballast (or slab track), plus the underlying subgrade. It enables trains to move by providing a dependable surface for their wheels to roll upon. For clarity it is often referred to as railway track (British English and UIC terminology) or railroad track (predominantly in the United States). 

Tracks where electric trains or electric trams run are equipped with an electrification system such as an overhead electrical power line or an additional electrified rail.

![Train Tracks](./traintrack.jpg)

Modern track typically uses hot-rolled steel with a profile of an asymmetrical rounded I-beam.[10] Unlike some other uses of iron and steel, railway rails are subject to very high stresses and have to be made of very high-quality steel alloy. It took many decades to improve the quality of the materials, including the change from iron to steel. The stronger the rails and the rest of the trackwork, the heavier and faster the trains the track can carry.

Other profiles of rail include: bullhead rail; grooved rail; "flat-bottomed rail" (Vignoles rail or flanged T-rail); bridge rail (inverted U–shaped used in baulk road); and Barlow rail (inverted V).

North American railroads until the mid- to late-20th century used rails 39 feet (12 m) long so they could be carried in gondola cars (open wagons), often 40 feet (12 m) long; as gondola sizes increased, so did rail lengths.