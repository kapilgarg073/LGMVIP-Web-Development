import styled from 'styled-components';

import BasicP from '../P';

const P = styled(BasicP)`
  margin: 0;
`;

export default P;