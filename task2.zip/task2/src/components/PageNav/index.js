import styled from 'styled-components';

const Wrapper = styled.div`
  margin-top: 50px;
  text-align: center;
`;

export default Wrapper;