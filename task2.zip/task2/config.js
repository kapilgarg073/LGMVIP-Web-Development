module.exports = {
  title: 'Blog', // Required
  author: 'Kapil Garg', // Required
  description: 'Full-stack Web Developer',
  primaryColor: '#3498db', // Required
  showHeaderImage: true,
  showShareButtons: true,
  postsPerPage: 5, // Required
  social: {
    github: 'https://github.com/kapilgarg073',
  },
  pathPrefix: '/task2',
  siteUrl: 'https://kapilgarg073.github.io/task2/',
};
